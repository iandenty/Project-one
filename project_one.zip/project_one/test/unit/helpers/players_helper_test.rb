require 'test_helper'

class PlayersHelperTest < ActionView::TestCase
end
