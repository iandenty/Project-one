# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
ProjectOne::Application.config.secret_token = '1154806159d6445bc455e846879962fd977f46d187fe2effd15f3649e0e7191d42d3724f2dc4de43655c4f9e03567c976006ca49ed6475dccad9d1243811ba81'
